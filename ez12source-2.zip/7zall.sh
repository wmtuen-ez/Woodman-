﻿#!/bin/bash

ver=12
license="doc/license/ezphrase.txt doc/license/gpl.txt"
zab="7za a -tbzip2 -mx=9 -mpass=7"
zaz="7za a -tzip -mx=9 -mpass=15"
zat="tar cvf"
outpath="output/zip"
gcinout="output/gcin"
oximout="output/oxim"
scimout="output/scim"
ibusout="output/ibus"
ovout="output/ov"
uimeout="output/uimetool"
ykkout="output/ykk"
ttsout="output/tts"
ttsdoc="doc/tts"

rm -rf $outpath
mkdir -p $outpath

$zat $outpath/ez"$ver"_gcin.tar $gcinout/gcin_ez.cin $license
$zab $outpath/ez"$ver"_gcin.tar.bz2 $outpath/ez"$ver"_gcin.tar
rm $outpath/ez"$ver"_gcin.tar
$zat $outpath/ezsmall"$ver"_gcin.tar $gcinout/gcin_ezsmall.cin $license
$zab $outpath/ezsmall"$ver"_gcin.tar.bz2 $outpath/ezsmall"$ver"_gcin.tar
rm $outpath/ezsmall"$ver"_gcin.tar
$zat $outpath/ezmid"$ver"_gcin.tar $gcinout/gcin_ezmid.cin $license
$zab $outpath/ezmid"$ver"_gcin.tar.bz2 $outpath/ezmid"$ver"_gcin.tar
rm $outpath/ezmid"$ver"_gcin.tar
$zat $outpath/ezbig"$ver"_gcin.tar $gcinout/gcin_ezbig.cin $license
$zab $outpath/ezbig"$ver"_gcin.tar.bz2 $outpath/ezbig"$ver"_gcin.tar
rm $outpath/ezbig"$ver"_gcin.tar

$zat $outpath/ez"$ver"_oxim.tar $oximout/oxim_ez.cin $license
$zab $outpath/ez"$ver"_oxim.tar.bz2 $outpath/ez"$ver"_oxim.tar
rm $outpath/ez"$ver"_oxim.tar
$zat $outpath/ezsmall"$ver"_oxim.tar $oximout/oxim_ezsmall.cin $license
$zab $outpath/ezsmall"$ver"_oxim.tar.bz2 $outpath/ezsmall"$ver"_oxim.tar
rm  $outpath/ezsmall"$ver"_oxim.tar
$zat $outpath/ezmid"$ver"_oxim.tar $oximout/oxim_ezmid.cin $license
$zab $outpath/ezmid"$ver"_oxim.tar.bz2 $outpath/ezmid"$ver"_oxim.tar
rm  $outpath/ezmid"$ver"_oxim.tar
$zat $outpath/ezbig"$ver"_oxim.tar $oximout/oxim_ezbig.cin $license
$zab $outpath/ezbig"$ver"_oxim.tar.bz2 $outpath/ezbig"$ver"_oxim.tar
rm  $outpath/ezbig"$ver"_oxim.tar

$zat $outpath/ez"$ver"_scim.tar $scimout/EZ.txt.in $license
$zab $outpath/ez"$ver"_scim.tar.bz2 $outpath/ez"$ver"_scim.tar
rm $outpath/ez"$ver"_scim.tar
$zat $outpath/ezsmall"$ver"_scim.tar $scimout/EZ-SMALL.txt.in $license
$zab $outpath/ezsmall"$ver"_scim.tar.bz2 $outpath/ezsmall"$ver"_scim.tar
rm $outpath/ezsmall"$ver"_scim.tar
$zat $outpath/ezmid"$ver"_scim.tar $scimout/EZ-MID.txt.in $license
$zab $outpath/ezmid"$ver"_scim.tar.bz2 $outpath/ezmid"$ver"_scim.tar
rm $outpath/ezmid"$ver"_scim.tar
$zat $outpath/ezbig"$ver"_scim.tar $scimout/EZ-Big.txt.in $license
$zab $outpath/ezbig"$ver"_scim.tar.bz2 $outpath/ezbig"$ver"_scim.tar
rm $outpath/ezbig"$ver"_scim.tar

$zat $outpath/ez"$ver"_ibus.tar $ibusout/ez.txt artwork/ez.svg $license
$zab $outpath/ez"$ver"_ibus.tar.bz2 $outpath/ez"$ver"_ibus.tar
rm $outpath/ez"$ver"_ibus.tar
$zat $outpath/ezsmall"$ver"_ibus.tar $ibusout/ez-small.txt artwork/ez.svg $license
$zab $outpath/ezsmall"$ver"_ibus.tar.bz2 $outpath/ezsmall"$ver"_ibus.tar
rm  $outpath/ezsmall"$ver"_ibus.tar
$zat $outpath/ezmid"$ver"_ibus.tar $ibusout/ez-mid.txt artwork/ez.svg $license
$zab $outpath/ezmid"$ver"_ibus.tar.bz2 $outpath/ezmid"$ver"_ibus.tar
rm $outpath/ezmid"$ver"_ibus.tar
$zat $outpath/ezbig"$ver"_ibus.tar $ibusout/ez-big.txt artwork/ez.svg $license
$zab $outpath/ezbig"$ver"_ibus.tar.bz2 $outpath/ezbig"$ver"_ibus.tar
rm $outpath/ezbig"$ver"_ibus.tar

$zaz $outpath/ez"$ver"_ov.zip $ovout/ov_ez.cin $license $ovlist
$zaz $outpath/ezsmall"$ver"_ov.zip $ovout/ov_ezsmall.cin $license
$zaz $outpath/ezmid"$ver"_ov.zip $ovout/ov_ezmid.cin $license
$zaz $outpath/ezbig"$ver"_ov.zip $ovout/ov_ezbig.cin $license

$zaz $outpath/ez"$ver"_ykk.zip $ykkout/ykk_ez.cin $license
$zaz $outpath/ezsmall"$ver"_ykk.zip $ykkout/ykk_ezsmall.cin $license
$zaz $outpath/ezmid"$ver"_ykk.zip $ykkout/ykk_ezmid.cin $license
$zaz $outpath/ezbig"$ver"_ykk.zip $ykkout/ykk_ezbig.cin $license
$zaz $outpath/ez"$ver"_uime.zip $uimeout/uime_ez.txt $license
$zaz $outpath/ezsmall"$ver"_uime.zip $uimeout/uime_ezsmall.txt $license
$zaz $outpath/ezmid"$ver"_uime.zip $uimeout/uime_ezmid.txt $license
$zaz $outpath/ezbig"$ver"_uime.zip $uimeout/uime_ezbig.txt $license

$zaz $outpath/ez"$ver"_tts.zip $ttsout/TableTextServiceEasy.txt $ttsdoc/ez32.reg $ttsdoc/ez64.reg $ttsdoc/install_ez.txt artwork/Easy.ico $license
$zaz $outpath/ezsmall"$ver"_tts.zip $ttsout/TableTextServiceEasySmall.txt $ttsdoc/ezsmall32.reg $ttsdoc/install_ezsmall.txt $ttsdoc/ezsmall64.reg artwork/EasySmall.ico $license
$zaz $outpath/ezmid"$ver"_tts.zip $ttsout/TableTextServiceEasyMid.txt $ttsdoc/ezmid32.reg $ttsdoc/ezmid64.reg $ttsdoc/install_ezmid.txt artwork/EasyMid.ico $license
$zaz $outpath/ezbig"$ver"_tts.zip $ttsout/TableTextServiceEasyBig.txt $ttsdoc/ezbig32.reg $ttsdoc/ezbig64.reg $ttsdoc/install_ezbig.txt artwork/EasyBig.ico $license

$zaz $outpath/ez"$ver"source.zip artwork changelog doc footer header maintable origtable script 7zall.sh makeall.sh readme.txt zipall.sh



